import { useState, useEffect, useRef } from 'react';
import { Link } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import LiveTranscript from '@/components/LiveTranscript';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import { toast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Plus, Phone, PhoneOff, Play, AlertCircle, Clock, CheckCircle, XCircle } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { formatDistanceToNow } from 'date-fns';

// Default call script template
const DEFAULT_SCRIPT = `Hello, this is Ella from YoBot.

I'm calling to follow up about our conversation earlier regarding our AI assistant services. 

I wanted to check if you had any questions about our platform or if you'd like to schedule a demonstration with one of our team members.

Would you be available for a 15-minute call this week to discuss how YoBot can help streamline your business operations?`;

// Form validation schema
const phoneCallSchema = z.object({
  to: z.string()
    .min(10, "Phone number must be at least 10 digits")
    .max(15, "Phone number is too long")
    .regex(/^[0-9+\-\s()]*$/, "Invalid phone number format"),
  script: z.string()
    .min(20, "Script must be at least 20 characters")
    .max(5000, "Script is too long (max 5000 characters)"),
  persona: z.string({
    required_error: "Please select a persona"
  }),
  voice: z.string({
    required_error: "Please select a voice"
  }),
  scheduledTime: z.string().optional(),
});

type PhoneCallFormValues = z.infer<typeof phoneCallSchema>;

// Call history interface
interface CallRecord {
  id: string;
  to: string;
  from: string;
  status: string;
  script: string;
  persona: string;
  voice: string;
  duration?: number;
  recordingUrl?: string;
  errorDetails?: string;     // For storing detailed error information
  errorCode?: string;        // For error codes or types
  retryCount?: number;       // For tracking retry attempts
  createdAt: string | Date;
  updatedAt: string | Date;
  scheduledTime?: string | Date;
}

export default function AICaller() {
  const [testAudio, setTestAudio] = useState<HTMLAudioElement | null>(null);
  const [selectedCall, setSelectedCall] = useState<CallRecord | null>(null);
  const [mobileMenu, setMobileMenu] = useState<boolean>(false);
  const queryClient = useQueryClient();
  
  // Fetch call history
  const {
    data: callHistory = [] as CallRecord[],
    isLoading: isHistoryLoading,
    error: historyError,
  } = useQuery<CallRecord[]>({
    queryKey: ['/api/phone-call/history'],
    retry: 1,
  });
  
  // Fetch personas for the dropdown
  interface Persona {
    id: string;
    name: string;
    description: string;
    systemPrompt: string;
    isDefault?: boolean;
  }
  
  interface PersonasResponse {
    success: boolean;
    personas: Persona[];
  }
  
  const {
    data: personasResponse,
    isLoading: isPersonasLoading,
  } = useQuery<PersonasResponse>({
    queryKey: ['/api/personas'],
    retry: 1,
  });
  
  // Extract personas array from response
  const personas = personasResponse?.personas || [];
  
  // Form setup
  const form = useForm<PhoneCallFormValues>({
    resolver: zodResolver(phoneCallSchema),
    defaultValues: {
      to: '',
      script: DEFAULT_SCRIPT,
      persona: 'default',
      voice: 'female',
    },
  });
  
  // Mutation to make a phone call
  const makeCallMutation = useMutation({
    mutationFn: (values: PhoneCallFormValues) => {
      // Simple validation before making the API call
      const phoneNumber = values.to.trim();
      if (!phoneNumber.match(/^\+?[1-9]\d{1,14}$/)) {
        throw new Error("Please enter a valid international phone number");
      }
      
      if (values.script.trim().length < 20) {
        throw new Error("Please enter a longer script message (at least 20 characters)");
      }
      
      return apiRequest('POST', '/api/phone-call', values);
    },
    onSuccess: (data) => {
      toast({
        title: "Call initiated",
        description: "Your call is being processed. Check the Call History tab for status updates.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/phone-call/history'] });
      // Don't reset the form so the user can make multiple calls with the same script
      form.setValue('to', '');
      
      // Set a timeout to refresh the call history again after a few seconds
      // This helps show updated call statuses without manual refresh
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: ['/api/phone-call/history'] });
      }, 5000);
    },
    onError: (error) => {
      toast({
        title: "Call failed",
        description: error instanceof Error ? error.message : "An error occurred with your request. Please check your connection and try again.",
        variant: "destructive",
      });
    },
  });
  
  // Test speech before making the call
  const testSpeechMutation = useMutation({
    mutationFn: async (text: string) => {
      const voice = form.getValues('voice');
      const persona = form.getValues('persona');
      
      try {
        const response = await fetch('/api/speech', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            text,
            personaId: persona,
            options: {
              stability: 0.5,
              similarityBoost: 0.8,
              style: 0.5,
              useSpeakerBoost: true,
            },
          }),
          // Adding a timeout to prevent hanging indefinitely
          signal: AbortSignal.timeout(15000),
        });
        
        if (!response.ok) {
          try {
            const error = await response.json();
            throw new Error(error.error || 'Failed to generate speech');
          } catch (e) {
            // If can't parse as JSON, use status text
            throw new Error(`Speech generation failed: ${response.statusText || response.status}`);
          }
        }
        
        const blob = await response.blob();
        return URL.createObjectURL(blob);
      } catch (err: any) {
        if (err && err.name === 'AbortError') {
          throw new Error('Speech generation timed out. Please try again.');
        }
        throw new Error(err && err.message ? err.message : 'Speech generation failed');
      }
    },
    onSuccess: (audioUrl) => {
      if (testAudio) {
        testAudio.pause();
        testAudio.src = '';
      }
      
      toast({
        title: "Script ready",
        description: "Playing the preview of how this will sound on a call",
      });
      
      const audio = new Audio(audioUrl);
      
      // Add error handling for audio playback
      audio.onerror = (e) => {
        toast({
          title: "Audio playback failed",
          description: "Could not play the audio. Please try again.",
          variant: "destructive",
        });
      };
      
      setTestAudio(audio);
      audio.play().catch((err: any) => {
        toast({
          title: "Audio playback failed",
          description: err && err.message ? err.message : "Failed to play audio. Check your browser settings.",
          variant: "destructive",
        });
      });
    },
    onError: (error) => {
      toast({
        title: "Speech generation failed",
        description: error instanceof Error 
          ? error.message 
          : "Failed to generate speech. This could be due to a network issue or service unavailability.",
        variant: "destructive",
      });
    },
  });
  
  // Clean up audio on unmount
  useEffect(() => {
    return () => {
      if (testAudio) {
        testAudio.pause();
        URL.revokeObjectURL(testAudio.src);
      }
    };
  }, [testAudio]);
  
  // Form submission handler
  const onSubmit = (values: PhoneCallFormValues) => {
    makeCallMutation.mutate(values);
  };
  
  // Test the script audio
  const handleTestScript = () => {
    const script = form.getValues('script');
    if (script.trim().length < 20) {
      toast({
        title: "Script too short",
        description: "Please enter a longer script to test",
        variant: "destructive",
      });
      return;
    }
    
    testSpeechMutation.mutate(script);
  };
  
  // Get status badge styling with enhanced error messages and tooltips
  const getStatusBadge = (status: string, errorDetails?: string, errorCode?: string) => {
    // Process the status to handle complex error cases
    let displayStatus = status.toLowerCase();
    let tooltip = '';
    
    // Extract error information if present in the status string
    if (displayStatus.includes('failed')) {
      // Handle specific error types with more detailed feedback
      if (displayStatus.includes('audio-generation-failed')) {
        displayStatus = 'audio-failed';
        tooltip = 'Audio generation failed. This could be due to an issue with the text-to-speech service.';
      } else if (displayStatus.includes('network-error')) {
        displayStatus = 'network-error';
        tooltip = 'Network connection issue. Please check your internet connection and try again.';
      } else if (displayStatus.includes('permission-denied')) {
        displayStatus = 'permission-denied';
        tooltip = 'Permission denied. Please check your API credentials and service authorization.';
      } else if (displayStatus.includes('resource-not-found')) {
        displayStatus = 'not-found';
        tooltip = 'Required resource was not found. Please check your configuration.';
      } else if (displayStatus.includes('rate-limited')) {
        displayStatus = 'rate-limited';
        tooltip = 'Rate limit exceeded. Please wait a few minutes before trying again.';
      } else if (displayStatus.includes('timeout')) {
        displayStatus = 'timeout';
        tooltip = 'Request timed out. The system will automatically retry.';
      } else if (displayStatus.includes('invalid-phone')) {
        displayStatus = 'invalid-phone';
        tooltip = 'Invalid phone number format. Please use international format (e.g., +15551234567).';
      } else if (displayStatus.includes('unreachable')) {
        displayStatus = 'unreachable';
        tooltip = 'The phone number is unreachable. Please verify it is correct and try again.';
      } else {
        tooltip = 'Call failed to complete. Check the error details for more information.';
      }
    } else if (displayStatus === 'busy') {
      tooltip = 'Recipient was busy. Try again later.';
    } else if (displayStatus === 'no-answer') {
      tooltip = 'Call was not answered. Try again later.';
    } else if (displayStatus === 'completed') {
      tooltip = 'Call completed successfully.';
    } else if (displayStatus === 'in-progress' || displayStatus === 'ringing') {
      tooltip = 'Call is currently active.';
    } else if (displayStatus === 'queued' || displayStatus === 'scheduled') {
      tooltip = 'Call is waiting to be processed.';
    } else if (displayStatus === 'initiating') {
      tooltip = 'Call is being initiated. This typically takes a few seconds.';
    } else if (displayStatus === 'generating-audio') {
      tooltip = 'Generating high-quality speech audio with ElevenLabs.';
    } else if (displayStatus === 'retrying') {
      tooltip = `Temporary failure occurred. System is automatically retrying the call${errorCode ? ` (Retry #${errorCode})` : ''}.`;
    }
    
    // Add error code to tooltip if available
    if (errorCode) {
      tooltip += ` (Error code: ${errorCode})`;
    }
    
    // Use detailed error message if provided (prioritize this over generated tooltips)
    if (errorDetails) {
      tooltip = errorDetails;
      // Still append error code if not already included in the details
      if (errorCode && !tooltip.includes(errorCode)) {
        tooltip += ` (Error code: ${errorCode})`;
      }
    }
    
    // Truncate very long tooltips for better UI
    if (tooltip.length > 250) {
      tooltip = tooltip.substring(0, 247) + '...';
    }
    
    // Render badge with appropriate styling and tooltip
    const badge = (() => {
      switch (displayStatus) {
        case 'completed':
          return <Badge className="bg-green-600"><CheckCircle className="h-3 w-3 mr-1" /> Completed</Badge>;
        
        // Error states with specific styling
        case 'failed':
          return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" /> Failed</Badge>;
        case 'audio-failed':
          return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" /> Audio Failed</Badge>;
        case 'network-error':
          return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" /> Network Error</Badge>;
        case 'permission-denied':
          return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" /> Permission Denied</Badge>;
        case 'timeout':
          return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" /> Timeout</Badge>;
        case 'not-found':
          return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" /> Not Found</Badge>;
        case 'rate-limited':
          return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" /> Rate Limited</Badge>;
        case 'invalid-phone':
          return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" /> Invalid Number</Badge>;
        case 'unreachable':
          return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" /> Unreachable</Badge>;
        
        // Call states
        case 'busy':
          return <Badge variant="destructive"><Phone className="h-3 w-3 mr-1" /> Busy</Badge>;
        case 'no-answer':
          return <Badge variant="destructive"><Phone className="h-3 w-3 mr-1" /> No Answer</Badge>;
        case 'in-progress':
        case 'ringing':
          return <Badge className="bg-blue-600"><Phone className="h-3 w-3 mr-1 animate-pulse" /> {displayStatus === 'in-progress' ? 'In Progress' : 'Ringing'}</Badge>;
        case 'queued':
        case 'scheduled':
          return <Badge variant="outline" className="border-amber-500 text-amber-500"><Clock className="h-3 w-3 mr-1" /> {displayStatus === 'queued' ? 'Queued' : 'Scheduled'}</Badge>;
        case 'initiating':
          return <Badge className="bg-blue-600"><Phone className="h-3 w-3 mr-1" /> Initiating</Badge>;
        case 'generating-audio':
          return <Badge className="bg-purple-600"><Play className="h-3 w-3 mr-1" /> Generating Audio</Badge>;
        
        // Retry states
        case 'retrying':
          return <Badge className="bg-amber-600 animate-pulse"><Clock className="h-3 w-3 mr-1" /> Retrying</Badge>;
        
        // Default/unknown status
        default:
          return <Badge variant="secondary">{status}</Badge>;
      }
    })();
    
    // Add tooltip if we have one
    return tooltip ? (
      <div className="relative group">
        {badge}
        <div className="absolute z-10 invisible group-hover:visible bg-black text-white text-xs rounded p-2 -mt-2 min-w-[200px] max-w-xs text-center">
          {tooltip}
        </div>
      </div>
    ) : badge;
  };
  
  // Format time for display
  const formatTimeAgo = (dateStr: string | Date) => {
    try {
      const date = typeof dateStr === 'string' ? new Date(dateStr) : dateStr;
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (e) {
      return 'Invalid date';
    }
  };
  
  // Format phone number for display
  const formatPhoneNumber = (phone: string) => {
    if (!phone) return '';
    
    // Keep only digits
    const digits = phone.replace(/\D/g, '');
    
    // Format based on length
    if (digits.length === 10) {
      return `(${digits.substring(0, 3)}) ${digits.substring(3, 6)}-${digits.substring(6)}`;
    } else if (digits.length === 11 && digits[0] === '1') {
      return `+1 (${digits.substring(1, 4)}) ${digits.substring(4, 7)}-${digits.substring(7)}`;
    }
    
    return phone;
  };
  
  return (
    <div>
      {/* Navigation Header */}
      <div className="bg-gradient-to-r from-[#0D82DA] to-blue-700 text-white py-3 px-4">
        <div className="container mx-auto">
          <div className="flex justify-between items-center">
            <Link href="/" className="text-white hover:text-blue-200 transition flex items-center py-2 px-2">
              <div className="mr-2 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
                </svg>
              </div>
              <span className="text-base">Home</span>
            </Link>

            {/* Mobile Navigation Buttons */}
            <div className="flex md:hidden items-center">
              <Link 
                href="/chat" 
                className="text-white bg-blue-600/50 hover:bg-blue-600 transition px-3 py-2 rounded-md text-sm mr-2 flex items-center"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
                Chat
              </Link>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center">
              <Link href="/chat" className="text-white hover:text-blue-200 transition mr-4 py-2 px-1">
                Chat with Ella
              </Link>
              <Link href="/admin" className="text-white hover:text-blue-200 transition py-2 px-1">
                Admin
              </Link>
            </div>
            
            {/* Mobile Navigation Toggle Button */}
            <div className="md:hidden">
              <button 
                onClick={() => setMobileMenu(!mobileMenu)} 
                className="text-white focus:outline-none"
                aria-label="Toggle Menu"
              >
                {!mobileMenu ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                )}
              </button>
            </div>
          </div>
          
          {/* Mobile Navigation Menu */}
          {mobileMenu && (
            <div className="md:hidden pt-4 border-t border-blue-400 mt-3">
              <nav>
                <ul className="flex flex-col space-y-3">
                  <li>
                    <Link href="/" className="text-white hover:text-blue-200 transition flex items-center py-2.5 px-2 rounded-md bg-blue-800/30" onClick={() => setMobileMenu(false)}>
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
                      </svg>
                      Home
                    </Link>
                  </li>
                  <li>
                    <Link href="/chat" className="text-white hover:text-blue-200 transition flex items-center py-2.5 px-2 rounded-md bg-blue-800/30" onClick={() => setMobileMenu(false)}>
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                      </svg>
                      Chat with Ella
                    </Link>
                  </li>
                  <li>
                    <Link href="/admin" className="text-white hover:text-blue-200 transition flex items-center py-2.5 px-2 rounded-md bg-blue-800/30" onClick={() => setMobileMenu(false)}>
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="3" y1="9" x2="21" y2="9"></line>
                        <line x1="9" y1="21" x2="9" y2="9"></line>
                      </svg>
                      Admin
                    </Link>
                  </li>
                </ul>
              </nav>
            </div>
          )}
        </div>
      </div>
      
      <div className="container mx-auto py-6 sm:py-10 px-4">
        <div className="flex flex-col md:flex-row justify-between items-center mb-6 sm:mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold mb-2">AI Phone Calls</h1>
            <p className="text-gray-600 max-w-2xl text-sm sm:text-base">
              Let Ella make outbound calls to follow up with leads, confirm appointments, or deliver personalized messages.
            </p>
          </div>
        </div>
      
      <Tabs defaultValue="make-call" className="w-full">
        <TabsList className="mb-4 w-full">
          <TabsTrigger className="text-base py-2.5 flex-1" value="make-call">Make a Call</TabsTrigger>
          <TabsTrigger className="text-base py-2.5 flex-1" value="call-history">Call History</TabsTrigger>
        </TabsList>
        
        <TabsContent value="make-call">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>New Outbound Call</CardTitle>
                <CardDescription>
                  Create a script and make an AI-powered phone call
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="to"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="+1 (555) 123-4567"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            Enter the recipient's phone number in international format
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="persona"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Persona</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a persona" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {isPersonasLoading ? (
                                  <SelectItem value="loading">Loading personas...</SelectItem>
                                ) : (
                                  Array.isArray(personas) ? personas.map((persona: any) => (
                                    <SelectItem key={persona.id} value={persona.id}>
                                      {persona.name}
                                    </SelectItem>
                                  )) : (
                                    // Fallback if the response structure is different
                                    <SelectItem value="default">Default Persona</SelectItem>
                                  )
                                )}
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Choose which personality Ella will use for the call
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="voice"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Voice Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a voice" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="female">Female</SelectItem>
                                <SelectItem value="male">Male</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Select the voice gender for this call
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="script"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Call Script</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Textarea
                                placeholder="Write your call script here..."
                                className="min-h-[200px] resize-y font-mono text-sm"
                                {...field}
                              />
                              <Button
                                type="button"
                                size="sm"
                                variant="secondary"
                                className="absolute bottom-2 right-2"
                                onClick={handleTestScript}
                                disabled={testSpeechMutation.isPending}
                              >
                                <Play className="h-4 w-4 mr-1" />
                                {testSpeechMutation.isPending ? "Testing..." : "Test Script"}
                              </Button>
                            </div>
                          </FormControl>
                          <FormDescription>
                            Write what Ella should say during the call. Use natural language and conversation flow.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-end gap-3">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => form.reset()}
                      >
                        Reset
                      </Button>
                      <Button
                        type="submit"
                        disabled={makeCallMutation.isPending}
                        className="bg-[#0D82DA] hover:bg-[#0956a3]"
                      >
                        <Phone className="mr-2 h-4 w-4" />
                        {makeCallMutation.isPending ? "Initiating Call..." : "Make Call"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Call Tips</CardTitle>
                <CardDescription>
                  Best practices for effective AI calls
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert className="bg-blue-50 border-blue-200">
                  <AlertTitle className="flex items-center text-blue-700">
                    <AlertCircle className="h-4 w-4 mr-2" />
                    Keep It Conversational
                  </AlertTitle>
                  <AlertDescription className="text-blue-600">
                    Write scripts that sound natural and conversational, not robotic or sales-y.
                  </AlertDescription>
                </Alert>
                
                <Alert className="bg-blue-50 border-blue-200">
                  <AlertTitle className="flex items-center text-blue-700">
                    <AlertCircle className="h-4 w-4 mr-2" />
                    Introduce Yourself Clearly
                  </AlertTitle>
                  <AlertDescription className="text-blue-600">
                    Always begin with a clear introduction of who you are and why you're calling.
                  </AlertDescription>
                </Alert>
                
                <Alert className="bg-blue-50 border-blue-200">
                  <AlertTitle className="flex items-center text-blue-700">
                    <AlertCircle className="h-4 w-4 mr-2" />
                    Include Pauses
                  </AlertTitle>
                  <AlertDescription className="text-blue-600">
                    Use commas and periods to create natural pauses in your script.
                  </AlertDescription>
                </Alert>
                
                <Alert className="bg-blue-50 border-blue-200">
                  <AlertTitle className="flex items-center text-blue-700">
                    <AlertCircle className="h-4 w-4 mr-2" />
                    Test Before Calling
                  </AlertTitle>
                  <AlertDescription className="text-blue-600">
                    Always use the "Test Script" button to hear how your message will sound.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="call-history">
          <Card>
            <CardHeader>
              <CardTitle>Recent Calls</CardTitle>
              <CardDescription>
                Review your recent outbound AI calls and their status
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isHistoryLoading ? (
                <div className="text-center py-4">Loading call history...</div>
              ) : historyError ? (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>
                    Failed to load call history. Please try again.
                  </AlertDescription>
                </Alert>
              ) : callHistory.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <PhoneOff className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                  <p>No calls have been made yet.</p>
                  <p>Switch to the "Make a Call" tab to place your first AI call.</p>
                </div>
              ) : (
                <div>
                  {/* Desktop table view */}
                  <div className="hidden md:block">
                    <Table>
                      <TableCaption>List of recent outbound calls</TableCaption>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Recipient</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Persona</TableHead>
                          <TableHead>Duration</TableHead>
                          <TableHead>Time</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {callHistory.map((call: CallRecord) => (
                          <TableRow 
                            key={call.id} 
                            className={`cursor-pointer hover:bg-gray-50 ${selectedCall?.id === call.id ? 'bg-blue-50' : ''}`}
                            onClick={() => setSelectedCall(call)}
                          >
                            <TableCell>{formatPhoneNumber(call.to)}</TableCell>
                            <TableCell>{getStatusBadge(call.status, call.errorDetails, call.errorCode)}</TableCell>
                            <TableCell>{call.persona}</TableCell>
                            <TableCell>
                              {call.duration ? `${Math.round(call.duration)}s` : '-'}
                            </TableCell>
                            <TableCell>{formatTimeAgo(call.createdAt)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  
                  {/* Mobile card view */}
                  <div className="md:hidden space-y-4">
                    {callHistory.map((call: CallRecord) => (
                      <Card 
                        key={call.id} 
                        className={`mb-4 cursor-pointer ${selectedCall?.id === call.id ? 'border-blue-400' : ''}`}
                        onClick={() => setSelectedCall(call)}
                      >
                        <CardContent className="pt-4">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <p className="font-medium">{formatPhoneNumber(call.to)}</p>
                              <p className="text-sm text-gray-500">{call.persona}</p>
                            </div>
                            <div className="text-right">
                              {getStatusBadge(call.status, call.errorDetails, call.errorCode)}
                            </div>
                          </div>
                          <div className="flex justify-between text-sm mt-2 pt-2 border-t border-gray-100">
                            <div>
                              {call.duration ? `${Math.round(call.duration)}s` : 'No duration'}
                            </div>
                            <div className="text-gray-500">
                              {formatTimeAgo(call.createdAt)}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>

            {/* Show transcript for selected call */}
            {selectedCall && (
              <div className="mt-4 p-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">
                    Call Details: {formatPhoneNumber(selectedCall.to)}
                  </h3>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => setSelectedCall(null)}
                  >
                    Close
                  </Button>
                </div>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Call Information</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2 text-sm">
                      <div className="grid grid-cols-2 gap-1">
                        <div className="font-medium">Status:</div>
                        <div>{getStatusBadge(selectedCall.status, selectedCall.errorDetails, selectedCall.errorCode)}</div>
                        
                        <div className="font-medium">To:</div>
                        <div>{formatPhoneNumber(selectedCall.to)}</div>
                        
                        <div className="font-medium">From:</div>
                        <div>{formatPhoneNumber(selectedCall.from)}</div>
                        
                        <div className="font-medium">Persona:</div>
                        <div>{selectedCall.persona}</div>
                        
                        <div className="font-medium">Voice:</div>
                        <div>{selectedCall.voice === 'female' ? 'Female' : 'Male'}</div>
                        
                        <div className="font-medium">Created:</div>
                        <div>{new Date(selectedCall.createdAt).toLocaleString()}</div>
                        
                        <div className="font-medium">Duration:</div>
                        <div>{selectedCall.duration ? `${Math.round(selectedCall.duration)} seconds` : 'Not completed'}</div>
                        
                        {selectedCall.errorDetails && (
                          <>
                            <div className="font-medium">Error:</div>
                            <div className="text-red-600">{selectedCall.errorDetails}</div>
                          </>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                  
                  <div>
                    <LiveTranscript 
                      callId={selectedCall.id} 
                      callStatus={selectedCall.status} 
                      highlightKeywords={['appointment', 'schedule', 'interested', 'declined', 'price', 'pricing', 'yes', 'no']}
                    />
                  </div>
                </div>
                
                <div className="mt-4">
                  <h4 className="font-medium mb-2">Call Script</h4>
                  <div className="bg-gray-50 p-3 rounded border text-sm whitespace-pre-wrap">
                    {selectedCall.script}
                  </div>
                </div>
              </div>
            )}
          </Card>
        </TabsContent>
      </Tabs>
      </div>
    </div>
  );
}